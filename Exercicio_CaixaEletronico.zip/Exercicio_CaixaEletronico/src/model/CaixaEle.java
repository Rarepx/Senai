package model;

public class CaixaEle {
	private double saldo;

	public CaixaEle() {
	}

	public CaixaEle(double saldo) {
		this.saldo = saldo;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	@Override
	public String toString() {
		return "Caixa [saldo=" + saldo + "]";
	}

}
