package controller;

import java.util.Scanner;

import model.CaixaEle;
import view.CaixaView;

public class CaixaController {
	private CaixaView caixaView;
	private CaixaEle caixaEle;
	Scanner scan = new Scanner(System.in);

	public CaixaController() {
		caixaView = new CaixaView();
		caixaEle = new CaixaEle();
	}

	public CaixaEle criarCaixa(double saldo) {
		CaixaEle caixa = new CaixaEle(saldo);
		return caixa;
	}

	public void exibirSaldoConta(CaixaEle caixa) {
		caixaView.exibirSaldo(caixa);
	}

	public void depositar(CaixaEle caixa) {
		caixaView.depositarText();
		double deposito = scan.nextDouble();
		caixa.setSaldo(deposito + caixa.getSaldo());
		caixaView.exibirSaldo(caixa);
	}

	public void sacar(CaixaEle caixa) {
		caixaView.sacarText();
		double saque = scan.nextDouble();
		if (saque <= caixa.getSaldo()) {
			caixa.setSaldo(caixa.getSaldo() - saque);
			caixaView.sacarSucesso(saque);
		} else {
			caixaView.sacarErro();
		}
	}

	public void menuInicial() {
		caixaView.menu();
		int menu =  caixaView.opcaoMenu();
		while (menu != 3) {
			switch (menu) {
			case 0:
				exibirSaldoConta(caixaEle);
				break;
			case 1:
				sacar(caixaEle);
				break;
			case 2:
				depositar(caixaEle);
				break;
			case 3:
				caixaView.mensagemTchau();
				break;
			default:
				caixaView.mensagemErro();
				break;
			}
		}
	}
}
