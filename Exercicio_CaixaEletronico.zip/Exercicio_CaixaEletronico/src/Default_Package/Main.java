package Default_Package;

import controller.CaixaController;




public class Main {

	public static void main(String[] args) {
		
		CaixaController c1 = new CaixaController();
		c1.menuInicial();
	}
}
