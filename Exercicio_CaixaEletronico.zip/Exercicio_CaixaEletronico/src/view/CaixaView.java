package view;

import java.util.Scanner;

import model.CaixaEle;

public class CaixaView {
	Scanner scan = new Scanner(System.in);

	public void exibirSaldo(CaixaEle caixa) {
		System.out.println("Saldo: R$" + caixa.getSaldo());
	}

	public void depositarText() {
		System.out.print("Insira o valor que deseja depositar: ");
	}

	public void sacarText() {
		System.out.print("Quanto deseja sacar: ");
	}

	public void sacarErro() {
		System.out.println("Erro! Voc� est� tentando sacar mais do que tem na conta.");
	}

	public void sacarSucesso(double valor) {
		System.out.println("Saque realizada com sucesso! R$" + valor + " Sacados");
	}
	
	public void menu() {
			System.out.println("===== Menu =====");
			System.out.println("0. Consultar Saldo");
			System.out.println("1. Sacar");
			System.out.println("2. Depositar");
			System.out.println("3. Sair");
			System.out.print("Digite uma op��o: ");
			
			
	}
	
	public int opcaoMenu() {
		int menu = scan.nextInt();
		return menu;
		
	}
	
	public void mensagemTchau() {
		System.out.println("Good Bye!!");
	}
	
	public void mensagemErro() {
		System.out.println("Digite uma op��o valida!");
	}
	
	

	
}

